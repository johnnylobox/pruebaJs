	
function tiempo(){

	var tiempo = new Date();
			
	document.write(tiempo.toDateString()); //toDateString simplifica la fecha.!

}

	function textoParpadeanteEfectos(){

			window.setInterval(BlinkIt, 500);

				var color = "white";

				var color2 = "cyan";

				var color3 = "red";

				var color4 = "#CEF6CE";
			
		
		function BlinkIt (){
			
			var blink = document.getElementById ("txt2");

			var blink2 = document.getElementById("txt");

			var blink3 = document.getElementById("txt3");

			var blink4 = document.getElementById("word");
			
			color = (color == "#BF00FF")? "white" : "#BF00FF";
			
			color2 = (color2 == "white")? "cyan" : "white";

			color3 = (color3 == "#1F66FF")? "red" : "#1F66FF";

			color4 = (color4 == "#00FF40")? "#CEF6CE" : "#00FF40";

			blink.style.color = color;
			
			blink.style.fontSize='36px';
				
			blink2.style.color = color2;

			blink2.style.fontSize='16px';

			blink3.style.color = color3;

			blink4.style.color = color4;

		}

/*			var bugsito=document.getElementById("bug");
			
				bugsito.style.width="200px";	*/

/*			var texto = document.getElementById("texto");
			
				texto.style.fontColor="black";		*/

		//	$(function(){ $("body").hide().fadeIn(2000); });

	}

function beginingOfAll(){

/*	var lugares = ["En la casa", "En el Trabajo", "Con mi novia Hironeay", "En la calle"]; 
	document.write(lugares[0]);*/

	//Codigo JavaScript		
		
	document.write("<p style='text-align:right;'><b>Venezuela <script> tiempo(); </script></b></p>");
	
	var nombre = prompt("Bienvenido introduce tu nombre: ");
	
	var pregunta;
	
		if(nombre == null){
			//alert("No has introducido ningun nombre");
		document.write("<div='container'><h3 id='txt'>");
		
		document.write("Iniciaste sesión como incognito..!!!");
		
		document.write("</h3></div>");
		
			}else{
 		
 				pregunta = prompt("Hay alguna persona a tu lado??");
		
					if(pregunta == "si" || pregunta == "Si" || pregunta == "SI"){
				
						var nombre2 = prompt("Introduce su nombre por favor");
				
						alert("Bienvenidos a esta pagina " + nombre + " y " + nombre2);
				
						document.write("<div='container'><h2 id='txt'>");
				
						document.write("Has iniciado sesión " +nombre+ ", Saludos a tu acompañante " +nombre2); 	
				
						document.write("</h2></div>");

					}else if(pregunta == "no" || pregunta == "No" || pregunta == "NO"){
						
						alert("Bienvenido " + nombre);
				
						document.write("<div='container'><h2 id='txt'>");
				
						document.write("Iniciaste sesión " + nombre);
				
						document.write("</h2></div>");
					
					}else{
				
						alert("Tu respuesta es invalida...");
				
						alert("Bienvenido de todas maneras " + nombre);
				
						document.write("<div='container'><h2 id='txt>");
				
						document.write("Iniciaste sesión " + nombre);
				
						document.write("</h2></div>");
				}
			}	
		
			if(nombre == null && nombre2 == null){
				
				document.write("<h1 class='hiro' align='center' id='txt2'>");
				
				document.write("Bienvenido....");
				
				document.write("</h1>");
			
			}else if(nombre != null && nombre2 != null){
				
				document.write("<h1 class='hiro' align='center' id='txt2'>");
				
				document.write("Bienvenido " +nombre+ " y tu acompañante " +nombre2);
				
				document.write("</h1>");
			
			}else{
				
				document.write("<h1 class='hiro' align='center' id='txt2'>");
				
				document.write("Bienvenido " +nombre);
				
				document.write("</h1>");
					
			}

		//Otra Funcion:

				$(function(){ $("body").hide().fadeIn(2000); });
		}

//#####################################################################################################

	
		function aprendiendoJquery(){

			$(document).ready(function()	{

				$("#pictures img").hide();

				$("#redesSociales a").hide();

//				$("#pictures img").hide().fadeIn(3000);

			});	

	/*		var imagenes=document.querySelectorAll("#pictures img");

				for(var i = 0; i < pictures.length; i++){

					pictures[i].style.visibility="hidden";

				}*/
		}


/*#################################################################################################*/


		function Prueba(){

			$(document).ready(function(){

//				$("#pictures2").width(500).height(500).text(" Juan Vargas - CTSI Desarrollo ").hide().fadeIn(10000);

				$("#pictures2").width(500).height(500).html("<h3 align='center' class='letra2'> Juan Vargas - CTSI Desarrollo </h3>").hide().fadeIn(3000);

			});

		} 


/*#################################################################################################*/


		function Formulario(){

			$(document).ready(function(){

				$("#formulario").prepend("<p><b>Hola</b></p>");

				$("#formulario").append("<p><b>Bienvenido al sistema</b></p>");

			});



		}


/*#################################################################################################*/


		function Validar(){

			var n_usuario = document.getElementById("usuario").value;

			var n_nombre = document.getElementById("nombre").value;

			var n_comentario = document.getElementById("comentario").value;

			if(n_usuario == ""){

//			alert("Haz dejado un campo vacio");

				$("#usuario").after("Rellena este campo");

			}

			if(n_nombre == ""){

//			alert("Haz dejado un campo vacio");

				$("#nombre").after("Rellena este campo");

			}

			if(n_comentario == ""){

//			alert("Haz dejado un campo vacio");

				$("#comentario").after("Añade tu comentario");

			}

		}




/*################### Función Banner ############################################################*/		

function Banner(){

			 //ready es una función

	$(document).ready(function(){

	$("#body").after("<div class='container' id='banner'><p id='word'>Welcome!!!</p><br><br><br> <div align='center'><button class='btn btn-danger' id='cerrar'>Cerrar</button></div></div>");

	/*	var x = document.getElementById("cerrar");

		x.addEventListener("click", cerrar_banner, false);

		});*/

	document.getElementById("cerrar").addEventListener("click", cerrar_banner, false); 

//	document.getElementById("imagen1").addEventListener("click", compra, false);  ### tipo 1 ###

	var imagenes = document.querySelectorAll("#pictures img");

	for(var i = 0; i < imagenes.length; i++){

	imagenes[i].addEventListener("click", compra, false); 

	}

	});


//###################################### Pertenece a Banner #############################################


	function cerrar_banner(){

	$("#banner").remove();

	}


//############################ Pertenece a Banner #############################################################


	function compra(arg){

		if(arg.target == imagen1){

		$("#imagen1").replaceWith("<h3 id='imagen1'>Seleccionado</h3>");
//		$("#imagen1").replaceWith("<h3>Seleccionado</h3>");	### tipo 1 ###

		}else if(arg.target == imagen2){

		$("#imagen2").replaceWith("<h3 id='imagen2'>Seleccionado</h3>");
//		$("#imagen1").replaceWith("<h3>Seleccionado</h3>");	### tipo 1 ###

		}else if(arg.target == imagen3){

		$("#imagen3").replaceWith("<h3 id='imagen3'>Seleccionado</h3>");
//		$("#imagen1").replaceWith("<h3>Seleccionado</h3>");	### tipo 1 ###

		}

	}

}


function resaltadores(){

	$(document).ready(function(){


	document.getElementById("buscadores").addEventListener("click", sombra_1, false);

	document.getElementById("social").addEventListener("click", sombra_2, false);
	
	});

	function sombra_1(){

		$(".social").removeClass("fondo"); //remueve el sombreado de la clase anterior remarcada

		$(".buscadores").addClass("fondo");

	//	$(".buscadores").toggleClass("fondo");

	}

	function sombra_2(){

		$(".buscadores").removeClass("fondo"); //remueve el sombreado de la clase anterior remarcada

		$(".social").addClass("fondo");	

//		$(".social").toggleClass("fondo");

	}

 }

function resaltadores2(){

	$(document).ready(function(){

	document.getElementById("buscadores2").addEventListener("click", sombra1, false);
	
	document.getElementById("social2").addEventListener("click", sombra2, false);
	
	});

		function sombra1(){

			$(".buscadores2").toggleClass("fondo");
		
		}

		function sombra2(){

			$(".social2").toggleClass("fondo");

		}
 }

 //#########################################################################################################################3

 function Fuentes(){

 	$(document).ready(function(){

 		var botones = document.querySelectorAll("input");

 		for(var i = 0; botones.length; i++){

 			botones[i].addEventListener("click", aumento, false);

 			botones[i].addEventListener("click", disminuye, false);

 		}

 	/*	document.getElementById("aumenta").addEventListener("click", aumento, false);

 		document.getElementById("aumenta2").addEventListener("click", aumento, false);
 		
 		document.getElementById("disminuir").addEventListener("click", disminuye, false);
 		
 		document.getElementById("disminuir2").addEventListener("click", disminuye, false);	*/


 	});

//----------------------------------------------

 	function aumento(e){

 		var dinamico;

 		if(e.target == aumenta){

 			dinamico = "#noticia";

 		}else if(e.target == aumenta2){

 			dinamico = "#noticia2";

 		}

 		var size=$(dinamico).css("font-size");

 		size=parseInt(size);

 		$(dinamico).css("font-size", size+2);

 	}

//-----------------------------------------------

 	function disminuye(arg){

 		var dinamico;

 		if(arg.target == disminuir){

 			dinamico = "#noticia";

 		}else if(arg.target == disminuir2){

 			dinamico = "#noticia2";

 		}

 		var size=$(dinamico).css("font-size");

 		size=parseInt(size);

 		$(dinamico).css("font-size", size-2);

 	}
 }

